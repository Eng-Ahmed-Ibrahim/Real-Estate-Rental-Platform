<?php
namespace App\Http\Middleware;

use App\Http\Controllers\API\ResponseTrait;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\App;

class CheckIfUserBlocked
{
    use ResponseTrait;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return \Illuminate\Http\Response
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();

        if ($user && $user->blocked) {
            
            $lang=$user->lang;
            // $user->tokens()->delete();
            App::setLocale($lang);
            return $this->Response(null,__('messages.This_Profile_Blocked_by_admin'),403);
        }

        return $next($request);
    }
}

